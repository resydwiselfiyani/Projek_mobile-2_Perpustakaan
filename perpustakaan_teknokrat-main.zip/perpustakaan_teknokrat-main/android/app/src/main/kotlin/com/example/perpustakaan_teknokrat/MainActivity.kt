package com.example.perpustakaan_teknokrat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
